from django.apps import AppConfig


class AppAauConfig(AppConfig):
    name = 'app_aau'
